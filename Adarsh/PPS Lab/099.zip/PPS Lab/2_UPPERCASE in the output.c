#include <stdio.h>

int main() {
   for(int i=0;i<5;i++)
   { char ch;
    ch=getchar();
    printf("%c",ch-32);}
    return 0;
}