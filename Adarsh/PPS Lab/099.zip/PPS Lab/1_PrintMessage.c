#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    printf("Hello12345\n\tWorld");
         
    return 0;
}
