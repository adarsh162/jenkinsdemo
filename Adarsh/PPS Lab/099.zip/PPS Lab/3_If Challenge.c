#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    int x,y,z;
    scanf("%d",& x);
    if(x>=0){
        y=printf("%d",x);
        printf("%d",y);
    }
    if(x<0){
    z=printf("%d",x);
    printf("%d",z);
    }
    return 0;
}
   
    


