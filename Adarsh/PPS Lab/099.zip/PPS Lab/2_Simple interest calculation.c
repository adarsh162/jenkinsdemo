#include <stdio.h>

int main() {
    int P,S;
    float R,N;
    scanf("%d",& P);
    scanf("%f",& R);
    scanf("%f",& N);
    printf("%ld\n",S=P*R*N/100); 
    return 0;
}