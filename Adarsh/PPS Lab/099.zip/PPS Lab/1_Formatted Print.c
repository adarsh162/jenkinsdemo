#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {

    printf("printf() function belongs to stdio.h header file\nYou need to include \"stdio.h\" using syntax: #include<stdio.h>\nThere are many format specifiers in the printf()\n\t%%d is the format specifier for integer(decimal)\n\t%%f is the format specifier for float(real numbers)\n\t%%c is the format specifier for a character\n\t%%s is the format specifier for string");  
      
    return 0;
}
